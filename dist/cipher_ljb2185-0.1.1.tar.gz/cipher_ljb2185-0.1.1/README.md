# cipher_ljb2185

Python package for encrytion technicque as part of MDS class deliverables

## Installation

```bash
$ pip install cipher_ljb2185
```

## Usage

- TODO

## Contributing

Interested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.

## Documentation

See the documentation here: [![Documentation Status](https://readthedocs.org/projects/cipher-ljb2185/badge/?version=latest)](https://cipher-ljb2185.readthedocs.io/en/latest/?badge=latest)

## License

`cipher_ljb2185` was created by Lestary J Barany. It is licensed under the terms of the MIT license.

## Credits

`cipher_ljb2185` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).
